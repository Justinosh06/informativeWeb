<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RECYCLE.</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Spicy+Rice&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Titan+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ultra&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Changa+One:ital@0;1&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Galada&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Wendy+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ranchers&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chango&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Reggae+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Seymour+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Agbalumo&family=Inter+Tight:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chela+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Agbalumo&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Monoton&family=MuseoModerno:ital,wght@0,100..900;1,100..900&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Prata&family=Raleway:ital,wght@0,100..900;1,100..900&family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

    <!--Import icons-->
    <script src="https://kit.fontawesome.com/f3ce044c74.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" type="text/css" href="../CSS/font.css">
    <link rel="stylesheet" type="text/css" href="../CSS/color.css">
    <link rel="stylesheet" type="text/css" href="../CSS/pageSetup.css">
    <link rel="stylesheet" type="text/css" href="../CSS/cursor.css">
    <link rel="stylesheet" type="text/css" href="../CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="../CSS/searchForm.css">
    <link rel="stylesheet" type="text/css" href="../CSS/animation.css">
    <link rel="stylesheet" type="text/css" href="../CSS/recyclingCenter.css">
    <link rel="stylesheet" type="text/css" href="../CSS/centerCard.css">
    <link rel="stylesheet" type="text/css" href="../CSS/notification.css">
    <link rel="stylesheet" type="text/css" href="../CSS/footer.css">
  </head>
  <script src="../JS/getUserLocation.js" charset="utf-8"></script>
  <body>
    <?php
        include "../HTML/cursor.html";
        include "../HTML/navbar.html";
    ?>

    <section id="recycling_center">
        <form action="#" method="get" class="search_form">
            <input type="type" class="search_box" placeholder="Recycling Center">
            <button type="submit" class="submit_btn"><i class='fa-solid fa-magnifying-glass'></i></button>
        </form>
        <div class="center_card_container">
            <div class="center_card">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15891.235071825648!2d100.25708078715822!3d5.292512900000017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x304abfeeb26cea8d%3A0x95573a5735b057d5!2sYAN%20BROTHERS%20INDUSTRIES%20SDN%20BHD%20PENANG%20(Recycle%20Used%20Carton%20Box%20Plastic%20Foam%20Sponge%20Pallet%20PE%20Foam%20Resin)!5e0!3m2!1szh-CN!2smy!4v1728698041320!5m2!1szh-CN!2smy" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                <div class="info">
                    <div class="text">
                        <h2 class="title">YAN BROTHERS INDUSTRIES SDN BHD PENANG</h2>
                        <div class="content">
                            <h5 class="subtitle">Recycle Used Carton Box Plastic Foam Sponge Pallet PE Foam Resin</h5>

                            <h6 class="distance" id="distance"></h6>
                            <script>getPosition(5.292513, 100.27613513, 'distance');</script>
                        </div>
                    </div>

                    <button class="navigation_btn" href="">navigate</button>
                </div>
            </div>
        </div>
    </section>

    <?php
        include "../HTML/footer.html";
    ?>
  </body>
  <script src="../JS/cursor.js" charset="utf-8"></script>
  <script src="../JS/footer.js" charset="utf-8"></script>
  <script src="../JS/navbar.js" charset="utf-8"></script>
</html>