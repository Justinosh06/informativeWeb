<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RECYCLE.</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Spicy+Rice&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Titan+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ultra&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Changa+One:ital@0;1&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Galada&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Wendy+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ranchers&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chango&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Reggae+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Seymour+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Agbalumo&family=Inter+Tight:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chela+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Agbalumo&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Monoton&family=MuseoModerno:ital,wght@0,100..900;1,100..900&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Prata&family=Raleway:ital,wght@0,100..900;1,100..900&family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

    <!--Import icons-->
    <script src="https://kit.fontawesome.com/f3ce044c74.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" type="text/css" href="../CSS/font.css">
    <link rel="stylesheet" type="text/css" href="../CSS/color.css">
    <link rel="stylesheet" type="text/css" href="../CSS/notification.css">
    <link rel="stylesheet" type="text/css" href="../CSS/pageSetup.css">
    <link rel="stylesheet" type="text/css" href="../CSS/index.css">
    <link rel="stylesheet" type="text/css" href="../CSS/cursor.css">
    <link rel="stylesheet" type="text/css" href="../CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="../CSS/menu.css">
    <link rel="stylesheet" type="text/css" href="../CSS/recycling_banner.css">
    <link rel="stylesheet" type="text/css" href="../CSS/recycling_intro.css">
    <link rel="stylesheet" type="text/css" href="../CSS/footer.css">
    <link rel="stylesheet" type="text/css" href="../CSS/animation.css">
  </head>
  <body id="body">

    <?php
      include "../HTML/cursor.html";
      //include "../HTML/notification.html";
      include "../HTML/navbar.html"; 
    ?>

    <section id="recycling_banner">
      <div class="recycling_container" id="recycling_container">
        <div class="header">
          <h4 class="deco_top">Recycle · Reuse · Reduce</h5>
          <h4 class="direct">></h4>
        </div>

        <div class="container_grid">
          <div class="col1">
            <div class="banner_title">
              <h2 class="bgText1 grotesk">Give your</h2>
              <h2 class="bgText1 grotesk"><span class="black_text">trash <img src="../image/recycleIcon.png" class="recycle_icon"></span> a second</h2>
              <h3 class="bgText2 grotesk">CHANCE.</h3>
            </div>
          </div>

          <div class="col2">
            <div class="banner_box">
              <i class="fa-solid fa-arrow-right banner_btn"></i>
            </div>
            <div class="banner_box">
              <i class="fa-solid fa-arrow-right banner_btn"></i>
            </div>
          </div>
        </div>

        <div class="incorporation_slider">
          <img src="../image/plastic-bag.png" class="slider_image" style="--delay_time: 0s">
          <img src="../image/plastic-bottle.png" class="slider_image" style="--delay_time: 1s">
          <img src="../image/Newspaper.png" class="slider_image" style="--delay_time: 2s">
          <img src="../image/Milk-Carton1.png" class="slider_image" style="--delay_time: 3s">
          <img src="../image/logo.png" class="slider_image" style="--delay_time: 4s">
          <img src="../image/logo.png" class="slider_image" style="--delay_time: 5s">
          <img src="../image/logo.png" class="slider_image" style="--delay_time: 6s">
          <img src="../image/logo.png" class="slider_image" style="--delay_time: 7s">
          <img src="../image/logo.png" class="slider_image" style="--delay_time: 8s">
          <img src="../image/logo.png" class="slider_image" style="--delay_time: 9s">
        </div>
      </div>
    </section>

    <section class="recycling_intro" id="recycling_intro">
      <div class="box_container">
        <div class="box">

        </div>
        <div class="box">

        </div>
      </div>
      <h2 class="intro_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</h2>
      <button type="button" class="intro_btn"><i class="fa-solid fa-arrow-right up_right_arrow"></i>Learn more</button>

      <div class="recycle_item_container">
        <div class="recycle_absolute">
          <div class="card" id="bottle">
            <div class="tooltip_recycle"><p class="tooltip_title" style="--delay_time: 0s">plastic bottle</p></div>
          </div>

          <div class="card_description">
            <div class="img_card">
              <img src="../image/Plastic-bottle.png" class="recyclable_item">
              <img src="../image/plastic-bag-composition.png" class="recyclable_composition">
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
        </div>

        <div class="recycle_absolute">
          <div class="card" id="bag">
            <div class="tooltip_recycle"><p class="tooltip_title" style="--delay_time: 2s">plastic bag</p></div>
          </div>

          <div class="card_description">
            <div class="img_card">
              <img src="../image/Plastic-bag.png" class="recyclable_item">
              <img src="../image/plastic-bag-composition.png" class="recyclable_composition">
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
        </div>
        <div class="recycle_absolute">
          <div class="card" id="milk">
            <div class="tooltip_recycle"><p class="tooltip_title" style="--delay_time: 1s">milk carton</p></div>
          </div>

          <div class="card_description">
            <div class="img_card">
              <img src="../image/Milk-Carton2.png" class="recyclable_item">
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
        </div>
        <div class="recycle_absolute">
          <div class="card" id="newspaper">
            <div class="tooltip_recycle"><p class="tooltip_title" style="--delay_time: 3s">newspaper</p></div>
          </div>

          <div class="card_description">
            <div class="img_card">
              <img src="../image/Newspaper.png" class="recyclable_item">
            </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
        </div>
      </div>
    </section>

    <?php
      include "../HTML/footer.html";
    ?>
  </body>

  <script>
    const home_black = document.querySelectorAll(".home_black");

    home_black.forEach((e) => {
      e.style.color = "#ececec";
    })
  </script>

  <script src="../JS/navbar.js" charset="utf-8"></script>
  <script src="../JS/cursor.js" charset="utf-8"></script>
  <script src="../JS/notification.js" charset="utf-8"></script>
  <script src="../JS/recycling_intro.js" charset="utf-8"></script>
  <script src="../JS/footer.js" charset="utf-8"></script>
</html>
