const cursor = document.getElementById("cursor");
const bottle = document.getElementById("bottle");
const bag = document.getElementById("bag");
const milk = document.getElementById("milk");
const newspaper = document.getElementById("newspaper");

document.addEventListener("mousemove", function(e){
  const body = document.getElementById("body");
  var left = e.clientX + window.pageXOffset;
  var top = e.clientY + window.pageYOffset;

  cursor.style.left = left + "px";
  cursor.style.top = top + "px";
})

bottle.addEventListener("mouseenter", function(e){
  cursor.style = "backdrop-filter: none";
  document.getElementById("cursor1").style.display = "inline";
})

bottle.addEventListener("mouseleave", function(e){
  cursor.style = "backdrop-filter: invert()";
  document.getElementById("cursor1").style.display = "none";
})

bag.addEventListener("mouseenter", function(e){
  cursor.style = "backdrop-filter: none";
  document.getElementById("cursor2").style.display = "inline";
})

bag.addEventListener("mouseleave", function(e){
  cursor.style = "backdrop-filter: invert()";
  document.getElementById("cursor2").style.display = "none";
})

milk.addEventListener("mouseenter", function(e){
  cursor.style = "backdrop-filter: none";
  document.getElementById("cursor3").style.display = "inline";
})

milk.addEventListener("mouseleave", function(e){
  cursor.style = "backdrop-filter: invert()";
  document.getElementById("cursor3").style.display = "none";
})

newspaper.addEventListener("mouseenter", function(e){
  cursor.style = "backdrop-filter: none";
  document.getElementById("cursor4").style.display = "inline";
})

newspaper.addEventListener("mouseleave", function(e){
  cursor.style = "backdrop-filter: invert()";
  document.getElementById("cursor4").style.display = "none";
})
