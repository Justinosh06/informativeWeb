function direct(){
    let loginBool = localStorage.getItem('bool');
    let loginDate = localStorage.getItem('date');
    const time = new Date();

    if(loginBool == null){
        localStorage.setItem('bool', 0);
        loginBool = 0;
    }

    if(loginBool == 0){
        window.location = "../php/adminLogin.php";
    } else if(loginBool == 1){
        let time = Date.now() - loginDate;
        if(time >= 604800000){
            loginBool = 0;
            localStorage.setItem('bool', 0);
            window.location = "../php/adminLogin.php";
        } else if(time < 604800000){
            window.location = "../php/adminDash.php";   
        }
    }
}