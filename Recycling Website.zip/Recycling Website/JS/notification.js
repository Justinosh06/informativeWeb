function alertNoti(title, text){
    const alert_title = document.getElementById("alert_title");
    const alert_text = document.getElementById("alert_text");
    const alert_notification = document.getElementById("alert_notification");

    alert_title.textContent = title;
    alert_text.textContent = text;

    alert_notification.classList.toggle("active");

    const timeout = setTimeout(function(){alert_notification.classList.toggle("active");}, 5000);
}

function messageNoti(title, text){
    const message_title = document.getElementById("message_title");
    const message_text = document.getElementById("message_text");
    const message_notification = document.getElementById("message_notification");

    message_title.textContent = title;
    message_text.textContent = text;

    message_notification.classList.toggle("active");

    const timeout = setTimeout(function(){message_notification.classList.toggle("active");}, 5000);
}