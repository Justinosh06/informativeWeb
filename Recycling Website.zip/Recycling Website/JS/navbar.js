const navbar_div = document.getElementById("navbar");
const navbar_btn = document.getElementById("navbar_btn");
const nav_btn = document.getElementById("nav_btn");
const navbar_logo = document.getElementById("navbar_logo");
const search_form = document.getElementById("search_form");
const search_icon = document.getElementById("search_icon");
const search_btn = document.getElementById("search_btn");
const searchbar = document.getElementById("searchbar");
const navbar_popUp = document.getElementById("menu");
const bg_text = document.getElementById("bg_text");
const recycling_banner = document.getElementById("recycling_banner");
var navbar_bool = false, search_bool = false;

window.onload = function(){
  const navbarWidth = parseInt(navbar_div.clientWidth, 10);

  navbar_btn.classList.add("fa-bars");

  navbar_logo.style = "--navbar_logo_size: 1.5rem";
}

window.addEventListener("resize", function(){
  const navbarWidth = parseInt(navbar_div.clientWidth, 10);

  navbar_logo.style = "--navbar_logo_size: 1.5rem";
});

function navbar(){
  if(navbar_bool == false){
    //navbar_popUp.classList.toggle("active");
    navbar_logo.classList.toggle("active");
    //search_form.classList.toggle("active");
    nav_btn.classList.toggle("active");
    navbar_logo.style = "font-size: 20px; font-weight: 700;";
    navbar_btn.classList.remove("fa-bars");
    navbar_btn.classList.add("fa-x");
    navbar_div.classList.toggle("active");
    document.body.scrollTop = 0;

    const home_black = document.querySelectorAll(".home_black");

    home_black.forEach((e) => {
      e.style.color = "#111";
    })

    navbar_bool = true;
  } else if(navbar_bool == true){
    //navbar_popUp.classList.toggle("active");
    navbar_logo.classList.toggle("active");
    //search_form.classList.toggle("active");
    navbar_logo.style = "--navbar_logo_size: 1.5rem";
    nav_btn.classList.toggle("active");
    navbar_btn.classList.remove("fa-x");
    navbar_btn.classList.add("fa-bars");
    navbar_div.classList.toggle("active");

    const home_black = document.querySelectorAll(".home_black");

    home_black.forEach((e) => {
      e.style.color = "#ececec";
    })

    navbar_bool = false;
  }
}

function bgText(element, text){
  const bg_text = document.getElementById("bg_text");

  bg_text.textContent = text;
  bg_text.classList.add("active");
}

function bgText_out(){
  bg_text.classList.remove("active");
}
/*window.onscroll = function(){
  if(document.body.scrollTop > 0){
    if(!recycling_container.classList.contains("min")){
      recycling_container.classList.add("min");
    }
    if(!navbar_div.classList.contains("sticky")){
      navbar_div.classList.add("sticky");
    }
  } else if(document.body.scrollTop == 0){
    recycling_container.classList.remove("min");
    navbar_div.classList.remove("sticky");
  }
}*/
