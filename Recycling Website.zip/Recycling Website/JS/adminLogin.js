const password = document.getElementById("password");
const visibilityBtn = document.getElementById("visibilityBtn");

var passwordVisibility = false;

function psVisibility(){
    if(passwordVisibility == false){
        password.type = "password";
    } else if(passwordVisibility == true){
        password.type = "text";
    }
}

visibilityBtn.onclick = function(){
    switch (passwordVisibility) {
        case false:
            passwordVisibility = true;
            visibilityBtn.classList.add("fa-eye");
            visibilityBtn.classList.remove("fa-eye-slash");
            psVisibility();
            break;
    
        case true:
            passwordVisibility = false
            visibilityBtn.classList.remove("fa-eye");
            visibilityBtn.classList.add("fa-eye-slash");
            psVisibility();
            break;
    }
}

window.onload = function(){
    psVisibility();
    visibilityBtn.classList.add("fa-eye-slash");
}