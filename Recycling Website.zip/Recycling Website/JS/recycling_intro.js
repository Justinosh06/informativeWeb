const recyclable_item = document.querySelectorAll(".recycle_absolute");

recyclable_item.forEach(function(item) {
  item.onclick = function(e) {
    console.log("run");
     this.classList.toggle("active");
  }
});
