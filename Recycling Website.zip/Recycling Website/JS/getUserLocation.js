let userLocation = [];
let placeLocation = [];

async function getPosition(lat, lon, element){
    await getUserPosition();

    placeLocation[0] = lat;
    placeLocation[1] = lon;

    console.log("Place: " + placeLocation);

    if(!isNaN(userLocation[0]) && !isNaN(userLocation[1])){
        displayDisplacement(element);
    } else{
        navigator.geolocation.getCurrentPosition(getUserPosition, function() {
            console.error("Failed to retrieve user location.");
        });
    }
}

function getUserPosition(){
    return new Promise((resolve, reject) => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    userLocation[0] = position.coords.latitude;
                    userLocation[1] = position.coords.longitude;
                    console.log("User: " + userLocation);
                    resolve(userLocation);  // Resolve the promise when user location is set
                },
                (error) => {
                    reject("Failed to retrieve user location: " + error.message);
                }
            );
        } else {
            reject("Geolocation is not supported by this browser!");
        }
    });
}

function degToRad(deg){
    return deg * Math.PI/180;
}

function calcDisplacement(lat1, lon1, lat2, lon2){
    var dLat = degToRad(lat2-lat1);
    var dLon = degToRad(lon2-lon1);

    if (isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2)) {
        console.error("Invalid location data");
        return NaN;  // Return NaN if data is invalid
    } else{
        var R = 6371; //Earth radius in km
        var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(degToRad(lat1)) * Math.cos(degToRad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2); 
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
        var d = R * c; // Distance in km
    
        return d;
    }
}

function displayDisplacement(element){
    let displacement = calcDisplacement(userLocation[0], userLocation[1], placeLocation[0], placeLocation[1]);

    document.getElementById(element).textContent = displacement.toFixed(2) + "km";
}